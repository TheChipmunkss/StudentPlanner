package SP;

import javax.swing.*;

import SP.Project.BoutonListener;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Desktop;

public class ntc extends JFrame{
	public ntc() {
		super();
		this.setTitle("Nourrit Ton Cerveau");
		this.setSize(290,260);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		JPanel panel = new JPanel(); // contient tous les objets à afficher
		
		panel.setLayout( new GridBagLayout() );
		GridBagConstraints c = new GridBagConstraints();
		
		Vector<String> vecList = new Vector <String>();
		DirectoryStream<Path> stream = null;
		String PDFfile;
		String nomRecette;
		try{
		      Path dir = Paths.get("recettes");
		      stream = Files.newDirectoryStream(dir, "*.pdf");
			  for (Path p: stream) {
				  PDFfile = p.getFileName().toString();
				  nomRecette = PDFfile.replaceFirst(".pdf", "");
				  vecList.add( nomRecette );
			  }	 
		} catch (IOException ex) {
		       ex.printStackTrace();
		}
				
		Collections.sort(vecList);
		JList<String> list = new JList<String>(vecList); // create Jlist from Vector
		JScrollPane scrollPane = new JScrollPane(list);
		//scrollPane.setBounds(0, 1, 50, 50);
		
		c.fill = GridBagConstraints.BOTH;
		c.gridx = 0;
		c.gridy = 0;
		panel.add(scrollPane, c); 		

        this.getContentPane().add(panel);
        //pack();
        
        MouseListener mouseListener = new MouseAdapter() {
            public void mouseClicked(MouseEvent mouseEvent) {
              JList theList = (JList) mouseEvent.getSource();
              if (mouseEvent.getClickCount() == 2) {
                int index = theList.locationToIndex(mouseEvent.getPoint());
                if (index >= 0) {
                  Object o = theList.getModel().getElementAt(index);
                  //System.out.println("Double-clicked on: " + o.toString());
                  try {
					Desktop.getDesktop().open(new File("recettes/" + o.toString() + ".pdf") );
                  } catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
                  }
                }
              }
            }
          };
          list.addMouseListener(mouseListener);
          
 		this.setVisible(true);
 	}
 	
 }